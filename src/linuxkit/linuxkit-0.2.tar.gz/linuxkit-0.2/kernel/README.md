See [../docs/kernels.md](../docs/kernels.md) for more information on kernel builds.
