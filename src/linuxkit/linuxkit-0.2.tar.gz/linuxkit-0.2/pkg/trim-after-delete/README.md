### trim-after-delete

This package runs `fstrim /var/lib/docker` after observing a Docker image delete event.
