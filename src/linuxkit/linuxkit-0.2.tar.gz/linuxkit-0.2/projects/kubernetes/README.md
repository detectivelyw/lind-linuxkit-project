# Kubernetes and LinuxKit

This project has now moved to https://github.com/linuxkit/kubernetes.
