export PS1="(ns: sshd) $PS1"
