include Proto.MakeRPC(Capnp_rpc_lwt)
