# SIGs

This directory will contain the descriptions for LinuxKit special interest groups (SIGs).

The community is welcome to participate in any special interest groups they would like - these meetings are completely
open to the public. Moreover, it is encouraged that participants suggest meeting agenda points via pull-requests.

Meeting notes will be posted promptly after each SIG meeting in the appropriate subdirectory.
