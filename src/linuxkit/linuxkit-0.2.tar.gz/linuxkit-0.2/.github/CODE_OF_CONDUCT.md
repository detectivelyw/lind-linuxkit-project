LinuxKit applies the [Docker code of conduct](https://github.com/docker/code-of-conduct).

For further information, see also the [contributing guide](CONTRIBUTING.md) and the [maintainers file](MAINTAINERS).
